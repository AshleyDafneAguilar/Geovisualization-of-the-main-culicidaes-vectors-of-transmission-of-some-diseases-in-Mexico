<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1">
<context>
    <name>Dialog</name>
    <message>
        <location filename="../pointSamplingToolUi.ui" line="17"/>
        <source>Point Sampling Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pointSamplingToolUi.ui" line="34"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pointSamplingToolUi.ui" line="48"/>
        <source>Layer containing sampling points:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pointSamplingToolUi.ui" line="68"/>
        <source>Layers with fields/bands to get values from:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pointSamplingToolUi.ui" line="99"/>
        <source>Output point vector layer:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pointSamplingToolUi.ui" line="110"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pointSamplingToolUi.ui" line="119"/>
        <source>Add created layer to the map</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pointSamplingToolUi.ui" line="130"/>
        <source>Fields</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pointSamplingToolUi.ui" line="167"/>
        <source>source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pointSamplingToolUi.ui" line="172"/>
        <source>name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pointSamplingToolUi.ui" line="181"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pointSamplingToolUi.ui" line="190"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The Point Sampling Tool Plugin collects polygon attributes and raster values from multiple layers at specified sampling points. You need a point layer with locations of sampling points and at least one polygon or raster layer to probe values from. The plugin creates a new point layer with locations given by the sampling points and attributes taken from all the underlying polygons or/and raster cells.&lt;/p&gt;&lt;p&gt;Please use Control and Shift keys in order to select multiple columns and bands.&lt;/p&gt;&lt;p&gt;NOTE: This tool is not compatible with mulitipoint sources, unless each multipoint contains exactly one point. Using multipoint samples that contain more points in multipoints may produce unreliable results.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pointSamplingToolUi.ui" line="233"/>
        <source>Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pointSamplingToolUi.ui" line="260"/>
        <source>Complete the input fields and press OK...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
